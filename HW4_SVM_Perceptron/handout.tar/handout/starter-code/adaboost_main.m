% Parameters 
% (Feel free to change the parameters for fun, 
% but use trainsize = 400; testsize = 100; for report)
trainsize = 400;
testsize = 100;
num_iter = 20;
[train.X, train.y] = gen_sample(trainsize);
[test.X, test.y] = gen_sample(testsize);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Your experiments goes here:
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%