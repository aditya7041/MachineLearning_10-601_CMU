function [log_product] = logProd(x)
  log_product = sum(x);
end

