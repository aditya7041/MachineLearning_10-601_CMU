load lr_train.mat;
display_network(train.X(:, 1:100));